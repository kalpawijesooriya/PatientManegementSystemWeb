# movie-db
More features in addition to http://github.com/time2hack/movieDB
