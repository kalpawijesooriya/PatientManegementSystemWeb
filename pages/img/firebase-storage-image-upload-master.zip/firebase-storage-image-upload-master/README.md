# firebase-storage-image-upload
upload image to firebase storage from app and view it, https://photo-upload-prithvi.firebaseapp.com/

Change API KEY with your FIrebase API Key below

var config = {
        apiKey: "",//change api key
        authDomain: "fir-f138c.firebaseapp.com",
        databaseURL: "https://fir-f138c.firebaseio.com",
        storageBucket: "fir-f138c.appspot.com",
        messagingSenderId: "918310331531"
    };
    
